const displayValElement = document.getElementById("calc-display-val");

let displayVal = "0"; //紀錄當下運算的數字
let pendingVal = "";  //記錄上一個要運算的數字
let evalStringArray = []; //紀錄運算的數字以及運算符號

//testtestetst

function decimal() {
    //當按下「.按鈕」請將displayVal數字上加上「.」，並顯示於displayValElement元件(20%)
    //注意如當數字已存在小數點時，就不會觸發該動作，請檢查當下的displayVal字串

}

function clearbtn() {
    //當按下「AC按鈕」請將所有運算狀態清空，displayVal也歸為零的狀態並顯示(20%)

}

function backspaceBtn(){
    //當按下「⇤按鈕」請將displayVal數字中，刪掉最後一個的數字，並重新顯示於displayValElement(20%)

}

//請在筆記中描述此函式在做什麼 (10%)
let updateDisplayVal = (clickObj) => {
    let btnText = clickObj.target.innerHTML;
    if (displayVal === "0") {
        displayVal = '';
    }

    displayVal += btnText;
    displayValElement.innerHTML = displayVal;
}

//請在筆記中描述此函式在做什麼 (10%)
let performOperation = (clickObj) => {
    let operator = clickObj.target.innerHTML;
    switch (operator) {
        case '+':
            pendingVal = displayVal;
            displayVal = '0';
            displayValElement.innerText = displayVal;
            evalStringArray.push(pendingVal);
            evalStringArray.push('+');
            break;
        case '-':
            pendingVal = displayVal;
            displayVal = '0';
            displayValElement.innerText = displayVal;
            evalStringArray.push(pendingVal);
            evalStringArray.push('-');
            break;
        case 'x':
            pendingVal = displayVal;
            displayVal = '0';
            displayValElement.innerText = displayVal;
            evalStringArray.push(pendingVal);
            evalStringArray.push('*');
            break;
        case '÷':
            pendingVal = displayVal;
            displayVal = '0';
            displayValElement.innerText = displayVal;
            evalStringArray.push(pendingVal);
            evalStringArray.push('/');
            break;
        case '=':
            evalStringArray.push(displayVal);
            let evaluation = eval(evalStringArray.join(' '));
            displayVal = evaluation + '';
            displayValElement.innerText = displayVal;
            evalStringArray = [];
            break;
        default:
            break;
    }
}

//取得所有數字按鈕，並幫所有數字按鈕掛上click事件處理(updateDisplayVal函式) (10%)


//取得所有運算按鈕，並幫所有運算按鈕掛上click事件處理(performOperation函式) (10%)