/*
 * 定義一個 scene，用成員變數儲存 scene 上面的物件
 * override preload, create, update 函式
 */
class Scene extends Phaser.Scene {
  /*********************************************************************************************************************** */
  constructor() {
    super();
    this.lastFireTime = null;
  }

  /*********************************************************************************************************************** */
  preload() {
    this.load.image(
      "rocket",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/spaceship.png?v=1699367937515"
    );
    this.load.image(
      "enemy",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/enemy.png?v=1699367630466"
    );
    this.load.image(
      "bullet",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/flame.png?v=1699367739459"
    );
    this.load.image(
      "block",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/block.png?v=1699367459981"
    );
    this.load.image(
      "bomb",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/bomb.png?v=1699367586681"
    );
  }

  /*********************************************************************************************************************** */
  create() {
    //建議主角及動態羣組：this.enemies, this.bullets, this.bombs

    ///////////////////////////

    for (let y = 30; y <= 200; y += 30) {
      for (let x = 100; x <= 700; x += 40) {
        //建立 enemies 並加入 enemies 羣組中
        //(scene, x, y, left, right)
      }
    }

    //設定在 this.bullets 和 this.enemies 之間的接觸事件處理

    //設定在 this.rocket 和 this.bombs 之間的接觸事件處理

    //設定在 this.bullets 和 this.bombs 之間的接觸事件處理

    this.blocks = this.physics.add.staticGroup();
    for (let y = 450; y <= 530; y += 10) {
      for (let x = 50; x <= 750; x += 10) {
        //建立 Block 物件，加入羣組
      }
    }

    //設定在 this.blocks  和 this.bullets 之間的接觸事件處理

    //設定在 this.blocks  和 this.bombs 之間的接觸事件處理

    //設定在 this.blocks  和 this.enemies 之間的接觸事件處理

    this.cursors = this.input.keyboard.createCursorKeys();
  }

  /*********************************************************************************************************************** */
  update() {
    //控制移動

    /////////////////////////////

    let now = new Date().getTime();
    if (this.cursors.space.isDown && this.rocket.body.enable) {
      if (this.lastFireTime == null || now - this.lastFireTime > 500) {
        //發射子彈
        /////////////////////
      }
    }
    this.enemies.children.iterate(function (enemy) {
      if (enemy.y >= 590) {
        //game over
        this.rocket.disableBody(true, true);
      }
      enemy.update();
    });

    this.bullets.children.iterate(function (bullet) {
      if (bullet.y <= 0) {
        bullet.disableBody(true, true);
      }
    });
  }
}