/*
 * 定義一個 scene，用成員變數儲存 scene 上面的物件
 * override preload, create, update 函式
 */
class Scene extends Phaser.Scene {
  /*********************************************************************************************************************** */
  constructor() {
    super();
    this.lastFireTime = null;
    //加入大絕 -1

    ////////////////
  }

  /*********************************************************************************************************************** */
  preload() {
   this.load.image(
      "rocket",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/spaceship.png?v=1699367937515"
    );
    this.load.image(
      "enemy",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/enemy.png?v=1699367630466"
    );
    this.load.image(
      "bullet",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/flame.png?v=1699367739459"
    );
    this.load.image(
      "block",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/block.png?v=1699367459981"
    );
    this.load.image(
      "bomb",
      "https://cdn.glitch.global/de902603-a667-4208-8ddb-31090ae1b402/bomb.png?v=1699367586681"
    );

    //把 rocket 加上放大絕前的動畫 加入大絕 -2

    ///////////////////////////

    //敵人的動畫 -1

    //////////////////
  }

  /*********************************************************************************************************************** */
  create() {
    this.rocket = new Rocket(this, 400, 580);
    this.enemies = this.physics.add.group();
    this.bullets = this.physics.add.group();
    this.bombs = this.physics.add.group();

    for (let y = 30; y <= 200; y += 30) {
      for (let x = 100; x <= 700; x += 40) {
        let enemy = new Enemy(this, x, y, x - 70, x + 100);
        this.enemies.add(enemy);
      }
    }
    this.physics.add.overlap(this.bullets, this.enemies, function (o1, o2) {
      o1.disableBody(true, true);
      o2.disableBody(true, true);
    });
    this.physics.add.overlap(this.rocket, this.bombs, function (o1, o2) {
      o1.disableBody(true, true);
      o2.disableBody(true, true);
    });
    this.physics.add.overlap(this.bullets, this.bombs, function (o1, o2) {
      o1.disableBody(true, true);
      o2.disableBody(true, true);
    });

    this.blocks = this.physics.add.staticGroup();
    for (let y = 450; y <= 530; y += 10) {
      for (let x = 50; x <= 750; x += 10) {
        if (Math.random() > 0.9) {
          let block = new Block(this, x, y);
          this.blocks.add(block);
        }
      }
    }

    this.physics.add.overlap(this.blocks, this.bullets, function (o1, o2) {
      o1.disableBody(true, true);
      o2.disableBody(true, true);
    });

    this.physics.add.overlap(this.blocks, this.bombs, function (o1, o2) {
      o1.disableBody(true, true);
      o2.disableBody(true, true);
    });

    this.physics.add.overlap(this.blocks, this.enemies, function (o1, o2) {
      o1.disableBody(true, true);
    });

    this.cursors = this.input.keyboard.createCursorKeys();

    //敵人的動畫 -2

    /////////////////////////////////

    //把 rocket 加上放大絕前的動畫 加入大絕 -3

    ///////////////////////////
  }

  /*********************************************************************************************************************** */
  update() {
    if (this.cursors.left.isDown) {
      this.rocket.setVelocityX(-160);
    } else if (this.cursors.right.isDown) {
      this.rocket.setVelocityX(160);
    } else {
      this.rocket.setVelocityX(0);
    }
    //加入大絕 -5

    ///////////////////

    let now = new Date().getTime();
    if (this.cursors.space.isDown && this.rocket.body.enable) {
      //加入大絕 -4
      if (this.lastFireTime == null || now - this.lastFireTime > 500) {
        let bullet = new Bullet(this, this.rocket.x, this.rocket.y);
        this.bullets.add(bullet);
        bullet.setVelocityY(-100);
        this.lastFireTime = now;
      }
      ////////////////////
    }
    this.enemies.children.iterate(function (enemy) {
      if (enemy.y >= 590) {
        //game over
        this.rocket.disableBody(true, true);
      }
      enemy.update();
    });

    this.bullets.children.iterate(function (bullet) {
      if (bullet.y <= 0) {
        bullet.disableBody(true, true);
      }
    });
  }
}